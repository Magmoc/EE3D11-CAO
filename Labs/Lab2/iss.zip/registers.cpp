#include <iostream>
#include "registers.h"

using namespace std;

Registers::Registers ()
{
}
