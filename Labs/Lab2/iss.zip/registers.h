#ifndef _REGISTERS_H_
#define _REGISTERS_H_

class Registers
{
};

#endif	/* _REGISTERS_H_ */
