#include <stdint.h>

void delay_ms (uint32_t);
void delay_us (uint32_t);

void init_delay (void);
