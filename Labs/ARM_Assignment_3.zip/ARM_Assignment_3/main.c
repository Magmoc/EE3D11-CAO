#include "LPC13xx.h"
#include "leddriver.h"
#include "delay.h"

#define SDA (IOCON->PIO0_5)
#define SCL (IOCON->PIO0_4)
#define I2C LPC_I2C

#define interruptflag 3
#define AA_flag 2

#define I2C_start 5
#define I2C_stop 4

#define TMP102_adress_read 0b10010000
#define TMP102_adress_write 0b10010001
#define REGISTER_NUMBER 0x0


void send_data(int data){
    I2C->DAT = data;
}

int read_data(){
    return I2C->DAT;
}

void send_NACK(){
    I2C->CONCLR |= (1<<AA_flag);
}

void wait_for_SI(){
    while ((I2C->CONSET & (1<<interruptflag)) == 0){ ; }
}

void clear_SI(){
    I2C->CONCLR |= (1<<interruptflag);
}

void olymeks_init(void){
    LPC_SYSCON->SYSAHBCLKCTRL |=(1<<5);         //enable clk to I2C
    LPC_SYSCON->PRESETCTRL |=(1<<1);            // deassert reset I2C
    I2C->CONSET |= (1<<I2C_start);          //If set to 1, enters mastermode
    I2C->SCLH = SystemCoreClock/100e3*0.5;              //set high duty cycle register
    I2C->SCLL = SystemCoreClock/100e3*0.5;              //set low duty cycle register
    I2C->CONSET |=(1<<6);                   //enable I2C interface

    I2C->CONCLR |= (1<<I2C_start);

    init_leds();
    set_leds(0b11110000);
    init_delay();
}

void master_receive(){
    int data_point;
    //start sequence
    I2C->CONSET |= (1<<I2C_start);          //start

    wait_for_SI();
    send_data(TMP102_adress_write);
    I2C->CONCLR |= (1<<I2C_start); // clear start
    clear_SI();

    wait_for_SI();
    send_data(REGISTER_NUMBER);
    clear_SI();

    wait_for_SI();
    while(1){
        I2C->CONSET |= (1<<I2C_start); // repeated start

        wait_for_SI();
        send_data(TMP102_adress_write);
        I2C->CONCLR |= (1<<I2C_start); // clear start
        clear_SI();

        wait_for_SI();
        data_point = read_data();
        set_leds(data_point);
        clear_SI();

        wait_for_SI();
        send_NACK();
        clear_SI();

        delay_ms(100);
    }

    //send_data(I2C_stop);
}


int main (void)
{

    //I2C->CONCLR |= (1<<interruptflag); //Flag reset
    //I2C->DAT                         //read/trite data

    olymeks_init();
	master_receive();
}
