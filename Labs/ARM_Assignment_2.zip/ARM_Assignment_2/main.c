#include "LPC13xx.h"
#include "timer.h"

#define TIMER0 LPC_TMR32B0
#define CLK_FREQ (72000000)
#define OUT1 LPC_GPIO1

//int freq, prescale_resolution, count_T, count_dT;
//float dutycycle, period_T_s;

int main (void){
    init();
    pin_high();
    timer_start();
    loop();

}


static void loop(void){
    while(1){
        while( (TIMER0->IR & ((1<<3)|(1<<0))) == 0){ }

        if((TIMER0->IR >> 3) & 1){ // read out MR3
            pin_high();
            TIMER0->IR |= (1 << 3) ; // reset MR3
        }
        else{
            if ((TIMER0->IR >> 0) & 1){ // read out MR0
                pin_low();
                //TIMER0->TCR |= (1<<1); // reset high
                TIMER0->IR |= (1 << 0); // reset MR0
            }
        }
    }
}

static void init(void){
    port_init();
    timer_init();
}

static void timer_init(void){
    int freq = 100;
    float dutycycle = 0.8;
    float period_T_s = 1/freq;
    float period_dT_s = dutycycle * period_T_s;
    float period_clk = 1/CLK_FREQ;

    int prescale_resolution = 1e3;
    float prescale_freq = (freq * prescale_resolution);
    int prescale_value = CLK_FREQ / prescale_freq;
    int   count_T = period_T_s * CLK_FREQ;
    int   count_dT = period_dT_s * CLK_FREQ;

    LPC_SYSCON -> SYSAHBCLKCTRL |= (1<<9);
    timer_stop();

    TIMER0->PR = 0;
    TIMER0->MCR |= (1<<0); // enable MR0 interrupt
    TIMER0->MCR |= (1<<9); // enable MR3 interrupt
    TIMER0->MCR |= (1<<10); // reset when MR3 is reached
    TIMER0->MR0 = count_dT;
    TIMER0->MR3 = count_T;
}
static void port_init(void){
     OUT1->DIR |= (1<<6);
     pin_low();
}

void pin_low(void){
    OUT1->DATA &= ~(1<<6);
}

void pin_high(void){
    OUT1->DATA |= (1<<6);
}

void timer_start(void){
    TIMER0->TCR |= (1<<0); // set CEN high : enable timer
    TIMER0->TCR &= ~(1<<0); // reset low
}

void timer_stop(void){
    TIMER0->TCR &= ~(1<<0); // set CEN low
    TIMER0->TCR |= (1<<1); // reset high
}
