#ifndef TIMER_H
#define TIMER_H

#include <stdbool.h>

static void init(void);
void pin_low(void);
void pin_high(void);
void timer_start(void);
void timer_stop(void);
static void loop(void);
static void timer_init(void);
static void port_init(void);

#endif // TIMER_H
